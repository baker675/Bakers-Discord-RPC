#!/bin/bash

pip install pypresence
python3 main.py
